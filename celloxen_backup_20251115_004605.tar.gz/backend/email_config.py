"""
Email System Configuration - WORKING!
"""

# IONOS SMTP Settings (WORKING CONFIGURATION)
SMTP_SERVER = "smtp.ionos.co.uk"
SMTP_PORT = 587
SMTP_USERNAME = "health@celloxen.com"
SMTP_PASSWORD = "Kuwait1000$$"
FROM_EMAIL = "health@celloxen.com"
FROM_NAME = "Celloxen Health"

# Database Settings (CORRECT PASSWORD)
DB_HOST = "localhost"
DB_NAME = "celloxen_portal"
DB_USER = "celloxen_user"
DB_PASSWORD = "CelloxenSecure2025"
